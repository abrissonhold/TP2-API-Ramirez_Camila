﻿namespace Application.Response
{
    public class GenericResponse
    {
        public int Id { get; set; }
        public required string Name { get; set; }
    }
}
